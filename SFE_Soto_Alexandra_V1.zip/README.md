# IMTA-report-latex

A project to convert the <a href="https://www.imt-atlantique.fr/" target="_blank">IMT Atlantique</a> document model to a LaTeX project. <br/>
Architecture inspired by  <a href="https://fr.sharelatex.com/templates/thesis/harvard-phd" target="_blank">Harvard Thesis</a>.
